import { HomePage } from './components/pages'
import './App.css'

function App() {
  return (
    <>
      <HomePage></HomePage>
    </>
  );
}

export default App;
