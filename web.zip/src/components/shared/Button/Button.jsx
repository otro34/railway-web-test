import {StyledButton} from './styles'

const Button = (props) => {
return <StyledButton>{props.value}</StyledButton>
}

export default Button