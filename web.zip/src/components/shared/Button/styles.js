import styled from 'styled-components'
import BsButton from 'react-bootstrap/Button';

export const StyledButton = styled(BsButton)`
    background-color: red;
`